import { logger } from "../utils/logger.js";

export function setupSocketHandlers(io) {
  io.on("connection", (socket) => {
    logger.info("Socket connected", { socketId: socket.id });

    // General room join (role-based rooms: "drivers", "providers", etc.)
    socket.on("join:room", ({ room }) => {
      if (room) {
        socket.join(room);
        logger.info("Socket joined room", { socketId: socket.id, room });
      }
    });

    // Driver joins their personal room to receive targeted notifications
    socket.on("driver:join", ({ driverId }) => {
      if (driverId) {
        socket.join(`driver:${driverId}`);
        logger.info("Driver socket registered", { driverId });
      }
    });

    // Provider joins their personal room
    socket.on("provider:join", ({ providerId }) => {
      if (providerId) {
        socket.join(`provider:${providerId}`);
        logger.info("Provider socket registered", { providerId });
      }
    });

    // Admin joins the admin broadcast room
    socket.on("admin:join", () => {
      socket.join("admin");
      logger.info("Admin socket registered", { socketId: socket.id });
    });

    socket.on("disconnect", () => {
      logger.info("Socket disconnected", { socketId: socket.id });
    });
  });

  logger.info("Socket handlers initialized");
}

socket.on(
  "provider-location",
  (data) => {

    io.emit(
      "provider-location-updated",
      data
    );

  }
);
